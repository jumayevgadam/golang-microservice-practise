package domain

// UserID represent user's id.
type UserID int64

// SkuID represent sku's id.
type SkuID uint32
