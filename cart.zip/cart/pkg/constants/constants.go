package constants

const (
	DBCtxTimeOut = 10
	SrvTimeOut   = 10
)
