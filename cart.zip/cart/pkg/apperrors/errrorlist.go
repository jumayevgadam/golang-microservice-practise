package apperrors
